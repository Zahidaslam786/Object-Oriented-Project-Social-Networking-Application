#pragma once
using namespace std;


class User : public Post
{
private:
    int currentUserID;
    string currentUserName;
    string* frd_list;
    int n_friend;
    int no_posts;
public:
    const int size = 10;
    Post* posts = new Post[size];
    User() : currentUserID(0), currentUserName(""), frd_list(nullptr), n_friend(0), no_posts(0) {}
    void setCurrentUser(int id, const string& name);
    int getCurrentUser() const;
    string getCurrentUserName() const;
    void addFriends(int numFriends, const string* userList, int userListSize);
    void displayfrd_list() const;
    void virtual new_post();
    void displayPosts() const;
    int getno_posts() const;
    void friendsposts() const;
    void addComment(int post_id, string comment);
    void Display_comments(int post_id) const;
    void displayTimeline() const;
    void displayHome() const;
    bool searchUser(const string& userName);
    void searchPostsByKeyword(const string& keyword);
    ~User()
    {
        delete[] frd_list; // Deallocate memory for the friend list
    }
};

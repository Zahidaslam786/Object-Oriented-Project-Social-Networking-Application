#include"SocialNetwork.h"
#include"Post.h"
#include"User.h"

int main()
{
    system("Color 06");
    cout << "\t\t\t\t       ===Social Networking Application===" << endl;
    User user;

    string name;
    int id;
    string currentUser;
    int currentUserId;
    int no_users_file = 0;

    ifstream myfile("users.txt");
    if (myfile.is_open())
    {
        cout << "\n\t\t\t\t\t\t'LIST OF USERS'" << endl;
        cout << "\n\n\t\t\t\t\tID'S \t\t\tNAME'S \n" << endl;
        while (myfile)
        {
            myfile >> name >> id;
            no_users_file++;
            cout << "\t\t\t\t\t|" << id << "|\t\t\t|" << name << "|" << endl;
        }
        myfile.close();
    }
    else
    {
        cout << "Unable to open" << endl;
        ////write users in file if file not found;
        ofstream ofile("users.txt");
        if (ofile.is_open())
        {
            int size;
            cout << "Enter No. of User You want to Enter in file" << endl;
            cin >> size;
            if (size < 0 && size>10)
            {
                cout << "Invalid Input! You Enter Maximum 10 user" << endl;
                cin >> size;
            }
            for (int i = 0; i < size; i++)
            {
                cout << "Enter Name and Id of user " << i + 1 << " : " << endl;
                cin >> name;
                ofile << name;
                ofile << "\t";
                cin >> id;
                ofile << id;
                ofile << endl;
            }
            ofile.close();
        }
    }
    cout << "\n\t\tEnter the current user ID: ";
    cin >> currentUserId;

    //check if userid is found or not.
    myfile.open("users.txt");
    if (myfile.is_open())
    {
        bool user_found = false;
        while (myfile)
        {
            myfile >> name >> id;
            if (id == currentUserId)
            {
                currentUser = name;
                user_found = true;
                break;
            }
        }
        myfile.close();
        if (user_found == false)
        {
            cout << "User not found." << endl;
        }
    }
    else
    {
        cout << "Failed to open the file." << endl;
    }
    system("cls");

    user.setCurrentUser(currentUserId, currentUser);  //SETTING THE CURRENT USER  

    int currentUserID = user.getCurrentUser();
    string currentUserName = user.getCurrentUserName();
    cout << "\n\n\nCurrent User ID: " << currentUserID << endl;
    cout << "Current User Name: " << currentUserName << endl;

    string* users_list = new string[no_users_file];
    //dynamic string that store all users name
    myfile.open("users.txt");
    int user_index = 0;
    if (myfile.is_open())
    {
        while (myfile)
        {
            myfile >> name >> id;
            users_list[user_index] = name;
            user_index++;
        }
        myfile.close();
    }
    else
    {
        cout << "Unable to open" << endl;
    }

    int ch;
    do
    {
        cout << "\n\n\t\t\t\t\tMENU\n\n\t\t\t\t1.View Friend List:\n\t\t\t\t2.Add Friends:\n\t\t\t\t3.Create Post:\n\t\t\t\t4.View Posts:\n\t\t\t\t5.View Friends Posts:\n\t\t\t\t6. Add Comment:\n\t\t\t\t7. Comments On Posts:\n\t\t\t\t8. Likes On Posts:\n\t\t\t\t9. Share post to timeline:\n\t\t\t\t10. View Timeline:\n\t\t\t\t11. View home Page:\n\t\t\t\t12. Search keyword & user \n\t\t\t\t0. Exit\n";
        cout << "Enter your choice: ";
        cin >> ch;
        switch (ch)
        {
        case 1:
            user.displayfrd_list();
            break;
        case 2:
            int no_friend;
            cout << "Enter the number of friends you want to add: ";
            cin >> no_friend;
            user.addFriends(no_friend, users_list, no_users_file);
            cout << endl;
            user.displayfrd_list();
            break;
        case 3:

            user.new_post();
            break;
        case 4:
            user.displayPosts();
            break;
        case 5:
            user.friendsposts();
            break;
        case 6:
            int post_id;
            cout << "Enter the post ID to add a comment: ";
            cin >> post_id;
            if (post_id >= 1 && post_id <= user.getno_posts())
            {
                string comment;
                cout << "Enter your comment: ";
                cin.ignore();
                getline(cin, comment);
                user.addComment(post_id, comment);
            }
            else
            {
                cout << "Invalid post ID. Please enter a valid one" << endl;
            }
            break;
        case 7:
            int c_post_id;
            cout << "Enter the post ID to  comments: ";
            cin >> c_post_id;
            if (c_post_id >= 1 && c_post_id <= user.getno_posts())
            {
                user.Display_comments(c_post_id);
            }
            else
            {
                cout << "Invalid post ID. Please enter a valid one\t" << endl;
            }
            break;
        case 8:
            int like_id;
            cout << "Enter the post ID to display likes: ";
            cin >> like_id;

            if (like_id >= 1 && like_id <= user.getno_posts())
            {
                user.posts[like_id - 1].gettotal_likes(like_id);
                user.posts[like_id - 1].display_total_likes();
            }
            else
            {
                cout << "Invalid post ID. Please enter a valid one" << endl;
            }
            break;
        case 9:
        {
            int no_posts;
            cout << "Enter the number of posts you want to share to the timeline: ";
            cin >> no_posts;
            ofstream time_line("timelinesharedposts.txt", ios::app);
            if (time_line.is_open())
            {
                for (int i = 0; i < no_posts; i++)
                {
                    int post_id;
                    cout << "Enter the post ID to share (Post " << i + 1 << "): ";
                    cin >> post_id;
                    if (post_id >= 1 && post_id <= user.getno_posts())
                    {
                        user.posts[post_id - 1].sharePost(post_id, currentUserID, currentUserName);
                    }
                    else
                    {
                        cout << "Invalid post ID. Please enter a valid one" << endl;
                    }
                }
                time_line.close();
            }
            else
            {
                cout << "Unable to open" << endl;
                break;
            }
            break;
        }
        case 10:
            user.displayTimeline();
            break;
        case 11:

            //user.setCurrentUser(currentUserId, currentUser);
            user.displayHome();
            break;
        case 12:
            int searchChoice;
            cout << "Choose search option:\n1. Search for a user\n2. Search for posts containing a keyword\n";
            cin >> searchChoice;

            if (searchChoice == 1) {
                string userName;
                cout << "Enter the user name to search: ";
                cin >> userName;
                user.searchUser(userName);
            }
            else if (searchChoice == 2) {
                string keyword;
                cout << "Enter the keyword to search posts: ";
                /*cin.ignore();
                getline(cin, keyword);*/
                cin >> keyword;
                user.searchPostsByKeyword(keyword);
            }
            else {
                cout << "Invalid choice!\n";
            }
            break;
        case 0:
            break;
        default:
            cout << "Invalid choice.Try Again" << endl;
        }
    } while (ch != 0);
    delete[] users_list;

    system("pause");
    return 0;
}
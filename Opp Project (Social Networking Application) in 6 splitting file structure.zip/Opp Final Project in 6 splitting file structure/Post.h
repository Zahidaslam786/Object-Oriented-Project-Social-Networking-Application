#pragma once
using namespace std;


class Post : public SocialEntity
{
protected:
    int post_id;
    string type;
    string details;
    int total_likes;
public:
    static int n_post;
    Post()
    {
        post_id = 0;
        type = "null";
        details = "null";
        total_likes = 0;
    }
    Post(int id, string postType, const string postdetails);
    Post(string t);
    void new_post(int id);
    void displayPost() const;
    string getType() const;
    string getdetails() const;
    int getpost_id() const;
    void gettotal_likes(int post_id);
    void display_total_likes() const; //Display total likes
    void sharePost(int post_id, int userId, string Name) const;
    bool containsKeyword(const string& keyword) const;
    virtual void Postdata(); //virtual Function
    ~Post() {}
};


class FeelingPost :public Post
{
public:
    FeelingPost(string t) :Post(t) {}
    virtual void Postdata() override;
};

class ThinkingPost :public Post
{
public:
    ThinkingPost(string t) :Post(t) {}
    virtual void Postdata() override;
};

class MakingPost :public Post
{
public:
    MakingPost(string t) :Post(t) {}
    virtual void Postdata() override;
};

class CelebratingPost :public Post
{
public:
    CelebratingPost(string t) :Post(t) {}
    virtual void Postdata() override;
};
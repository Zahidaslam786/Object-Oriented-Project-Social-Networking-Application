#include"SocialNetwork.h"
#include"Post.h"
#include"User.h"

SocialEntity::SocialEntity(string n, int i)
    : name(n), id(i) {}
string SocialEntity::getName() const
{
    return name;
}
int SocialEntity::getId() const
{
    return id;
}

void SocialEntity::GetTime()
{
    cout << __DATE__ << " , " << __TIME__ << endl;
}
#include"SocialNetwork.h"
#include"Post.h"
#include"User.h"

void User::setCurrentUser(int id, const string& name)
{
    currentUserID = id;
    currentUserName = name;
}
int User::getCurrentUser() const
{
    return currentUserID;
}
string User::getCurrentUserName() const
{
    return currentUserName;
}
void User::addFriends(int numFriends, const string* userList, int userListSize)
{

    string* newfrd_list = new string[n_friend + numFriends]; // For the new friend list

    for (int i = 0; i < n_friend; i++)// Copy existing friends
    {
        newfrd_list[i] = frd_list[i];
    }
    for (int i = 0; i < numFriends; i++)// Add new friends to the end of the list
    {
        string friendName;    //add new friend 
        bool exsist = false;
        do
        {
            cout << "Enter the name of friend " << (i + 1) << ": ";
            cin >> friendName;
            if (friendName == getCurrentUserName())
            {
                cout << "Invalid friend! (You cannot make yourself a friend) " << endl;
            }
            else
            {
                for (int j = 0; j < userListSize; j++)//check friend list
                {
                    if (userList[j] == friendName)
                    {
                        exsist = true;
                        break;
                    }
                }
                if (exsist == false)   //false
                {
                    cout << "Friend Not Found!  Please Enter again" << endl;
                }
            }
        } while (!exsist);
        newfrd_list[n_friend + i] = friendName; //add new friends in dynamic friend list
    }
    frd_list = newfrd_list;// Update the friend
    n_friend += numFriends;// Update count
    ofstream friendFile("friend.txt", ios::app);
    if (friendFile.is_open())
    {
        friendFile << "Friend List of " << currentUserName << " (ID: " << currentUserID << "):" << endl;
        for (int i = 0; i < n_friend; i++)
        {
            friendFile << frd_list[i] << endl;
        }
        friendFile << "------------------------" << endl;
        friendFile.close();
        cout << "Friend List Store" << endl;
    }
    else
    {
        cout << "Unable to Open" << endl;
    }
}
void User::displayfrd_list() const
{
    int id;
    string name;
    cout << "\nFriend List of " << currentUserName << " (ID: " << currentUserID << "):" << endl;
    ifstream myfile("friend0.txt");
    if (n_friend == 0)  //if NO friend it read the file and show previous friend
    {
        if (myfile.is_open())
        {
            while (myfile)
            {
                myfile >> id;
                getline(myfile, name);
                if (id == currentUserID)
                {
                    cout << "Previous friends of : " << currentUserName << " is : " << name << "\n";

                }
            }
        }
        else
        {
            cout << "Unable to open \n";
        }
    }
    //Display Friend of current user
    for (int i = 0; i < n_friend; i++)
    {
        cout << frd_list[i] << endl;
    }
}
void  User::new_post()
{
    if (no_posts >= 10)
    {
        cout << "Limit of 10 posts reached! ,You Cannot create a new post" << endl;
    }
    posts[no_posts].new_post(no_posts + 1); //pass the id
    no_posts++;
    ofstream postFile("post.txt", ios::app);

    if (postFile.is_open())
    {
        postFile << "\nPosts of " << currentUserName << " (ID: " << currentUserID << "):" << endl;
        for (int i = 0; i < no_posts; i++)
        {
            postFile << "\nPost ID: " << posts[i].getpost_id() << endl;
            postFile << "Post Type: " << posts[i].getType() << endl;
            postFile << "details: " << posts[i].getdetails() << endl;
        }
        postFile << "------------------------" << endl;
        postFile.close();
        cout << "Data store" << endl;
    }
    else
    {
        cout << "Unable to open" << endl;
    }
}

void User::displayPosts() const
{
    cout << "\nPosts of " << currentUserName << " (ID: " << currentUserID << "):" << endl;
    if (no_posts == 0)
    {
        cout << "No posts found" << endl;
    }
    else
    {
        for (int i = 0; i < no_posts; i++)
        {
            posts[i].displayPost();
        }
    }
}

int User::getno_posts() const
{
    return no_posts;
}

void User::friendsposts() const
{
    int userId, id;
    string str, str1;
    cout << "Enter the user ID to view their friends posts: ";
    cin >> userId;
    ifstream inputFile("friends_posts.txt");
    if (inputFile.is_open())
    {
        while (inputFile)
        {
            inputFile >> str1;
            inputFile >> id;
            getline(inputFile, str); //input post
            if (userId == id)
            {
                cout << "\n\n\t\tFriend's Post\n";
                cout << "\n\t Name : " << str1 << ", Id : " << id << "\n";
                cout << "\t post is : '" << str << " '\n\n";
            }
        }
        inputFile.close();
    }
}

void User::addComment(int post_id, string comment)
{
    ofstream commentFile("comments.txt", ios::app);
    if (commentFile.is_open())
    {
        commentFile << currentUserID << "\t" << post_id << "\t" << comment << endl;
        commentFile.close();
        cout << "Comment added" << endl;
    }
    else
    {
        cout << "Unable to open" << endl;
    }
}

void User::Display_comments(int post_id) const
{
    cout << "\View Comments of " << currentUserName << "'s Posts (Post ID: " << post_id << "):" << endl;
    ifstream commentFile("comments.txt");
    if (commentFile.is_open())
    {
        int post;
        string user, comments;
        bool commentsFound = false;
        while (commentFile)
        {
            commentFile >> post >> user;
            getline(commentFile, comments);
            if (post == post_id)
            {
                cout << "\nUser: " << user << "\n Comments: " << comments << endl;
                commentsFound = true;
            }
        }
        commentFile.close();
        if (commentsFound == false)
        {
            cout << "No comments found for Post ID " << post_id << endl;
        }
    }
    else
    {
        cout << "unable to open" << endl;
    }
}
void User::displayTimeline() const
{
    cout << "\nTimeline of " << currentUserName << " (ID: " << currentUserID << "):" << endl;
    cout << "\t\tYour Timeline Post on ";
    GetTime();
    cout << endl << endl;

    //Post::displayPost();
    ifstream time_line("timelinesharedposts.txt");
    if (time_line.is_open())
    {
        string str;
        bool userFound = false;
        while (getline(time_line, str))
        {
            cout << str << endl;
        }
        GetTime();
        time_line.close();
    }
    else
    {
        cout << "Unable to open\n";
    }
}

void User::displayHome() const
{
    cout << "\t\t\t\t\t=== Home ===" << endl;
    cout << "Current User ID: " << currentUserID << endl;
    cout << "Current User Name: " << currentUserName << endl;
    cout << "\nFriend Posts:" << endl;
    friendsposts();
    cout << "\nYour Posts:" << endl;
    Post::displayPost();
    for (int i = 0; i < no_posts; i++)
    {
        cout << "-------------Likes and Comments--------------" << endl;
        posts[i].display_total_likes();
        Display_comments(posts[i].getpost_id());
    }
}

void User::searchPostsByKeyword(const string& keyword) 
{
    ifstream myFile("Posts.txt");

    if (!myFile.is_open()) {
        cout << "Failed to open 'Posts.txt'." << endl;
        return;
    }

    int id;
    string Type, Detail;

    while (myFile >> id >> Type)
    {
        cout << "Id: " << id << endl;
        cout << "Type: " << Type << endl;
        getline(myFile, Detail);
        cout << "Detail: " << Detail << endl;
        Detail = Detail.substr(Detail.find_first_not_of(" \t\n\r\f\v"), Detail.find_last_not_of(" \t\n\r\f\v") + 1);
        string firstWord = Detail.substr(0, Detail.find(' '));
        // Check if the word matches the keyword
        if (firstWord == keyword) {
            cout << "Keyword matched!\n";
            cout << "Post ID: " << id << "\nPost Type: " << Type << "\nDetails: " << Detail << endl;
            myFile.close();
            return;
        }
    }
    cout << "Keyword not matched!\n";
    myFile.close();
}

bool User::searchUser(const string& userName)
{
    ifstream userFile("users.txt");

    if (!userFile.is_open()) {
        cout << "Failed to open 'users.txt'." << endl;
        return false;
    }

    string name;
    int id;

    while (userFile >> name >> id) 
    {
        if (name == userName) 
        {
            cout << "User found!\n";
            cout << "ID: " << id << "\nName: " << name << endl;
            userFile.close();
            return true;
        }
    }

    cout << "User not found!\n";
    userFile.close();
    return false;
}




#include"SocialNetwork.h"
#include"Post.h"
#include"User.h"


int Post::n_post = 0;
//string details;
void Postdetails(string type);   

void FeelingPost::Postdata()
{
    cout << "the type of the post is : " << type << "\n";
    cout << "Enter details For The Post: ";
    cin.ignore();
    getline(cin, details);

    ofstream postFile("Posts.txt", ios::app);
    if (postFile.is_open())
    {
        postFile << "\nPost ID: " << ++n_post << endl;
        postFile << "Post Type: " << getType() << endl;
        postFile << "details: " << details << endl;
        postFile << "------------------------" << endl;
        postFile << endl;
        postFile.close();
    }
    else
    {
        cout << "Unable to open" << endl;
    }
}


void ThinkingPost::Postdata()
{
    cout << "the type of the post is : " << type << "\n";
    cout << "Enter details For The Post: ";
    cin.ignore();
    getline(cin, details);
    ofstream postFile("Posts.txt", ios::app);
    if (postFile.is_open())
    {
        postFile << "\nPost ID: " << ++n_post << endl;
        postFile << "Post Type: " << getType() << endl;
        postFile << "details: " << details << endl;
        postFile << "------------------------" << endl;
        postFile << endl;
        postFile.close();
    }
    else
    {
        cout << "Unable to open" << endl;
    }
}

void MakingPost::Postdata()
{
    cout << "the type of the post is : " << type << "\n";
    cout << "Enter details For The Post: ";
    cin.ignore();
    getline(cin, details);
    ofstream postFile("Posts.txt", ios::app);
    if (postFile.is_open())
    {
        postFile << "\nPost ID: " << ++n_post << endl;
        postFile << "Post Type: " << getType() << endl;
        postFile << "details: " << details << endl;
        postFile << "------------------------" << endl;
        postFile << endl;
        postFile.close();
    }
    else
    {
        cout << "Unable to open" << endl;
    }
}

void CelebratingPost::Postdata()
{
    cout << "the type of the post is : " << type << "\n";
    cout << "Enter details For The Post: ";
    cin.ignore();
    getline(cin, details);
    ofstream postFile("Posts.txt", ios::app);
    if (postFile.is_open())
    {
        postFile << "\nPost ID: " << ++n_post << endl;
        postFile << "Post Type: " << getType() << endl;
        postFile << "details: " << details << endl;
        postFile << "------------------------" << endl;
        postFile << endl;
        postFile.close();
    }
    else
    {
        cout << "Unable to open" << endl;
    }
}


void Post::Postdata()
{}

Post::Post(int id, string postType, const string postdetails)
    : post_id(id), type(postType),details(postdetails),total_likes(0)
{}
Post::Post(string t) : type(t) {}
void Post::new_post(int id)
{
    post_id = id;
    cout << "\nCreate a new post:" << endl;

    cout << "\t\t\tSelect Post Type:\n" << endl;
    cout << "\n\t\t 1. \"Feeling\"     (Happy/Sad/Excited etc)" << endl;
    cout << "\n\t\t 2. \"Thinking\"   (Life/Future/Meaning of life etc)" << endl;
    cout << "\n\t\t 3. \"Making\"      (Money/Art/Memories etc)" << endl;
    cout << "\n\t\t 4. \"Celebrating\"  (A birthday/Halloween/Success etc)\n\n" << endl;

    int choice;
    cout << "Enter the type number: ";
    cin >> choice;
    switch (choice)
    {
    case 1:
        type = "Feeling";
        Postdetails(type);
        break;
    case 2:
        type = "Thinking";
        Postdetails(type);
        break;
    case 3:
        type = "Making";
        Postdetails(type);
        break;
    case 4:
        type = "Celebrating";
        Postdetails(type);
        break;
    default:
        cout << "Invalid choice!" << endl;
        cin >> choice;
    }
}


string Post::getType() const
{
    return type;
}
string Post::getdetails() const
{
    return details;
}
int Post::getpost_id() const
{
    return post_id;
}

void Post::displayPost() const
{
    cout << "------------- Post ------------" << endl;
    ifstream myfile("Posts.txt", ios::app);
    if (myfile.is_open())
    {
        string str;
        while (getline(myfile, str))
        {
            cout << str << endl;
        }
        myfile.close();
    }
    else
    {
        cout << "Unable to open" << endl;
    }

}
void Post::gettotal_likes(int post_id)// To get likes
{
    ifstream likesFile("likes.txt");
    int post, userId;
    if (likesFile.is_open())
    {
        while (likesFile)
        {
            likesFile >> post >> userId;
            if (post == post_id)
            {
                cout << "The Post Liked By User : " << userId << endl;
                total_likes++;
            }
        }
        likesFile.close();
    }
    else
    {
        cout << "Failed to open 'likes.txt'." << endl;
    }
}
void Post::display_total_likes() const//To display total likes
{
    cout << "------------Total Likes-----------" << endl;
    cout << "Total Likes: " << total_likes << endl;
}
void Post::sharePost(int post_id, int userId, string Name) const
{
    ofstream time_line("timelinesharedposts.txt", ios::app);// writing shared posts
    if (time_line.is_open())
    {
        time_line << "User ID: " << userId << endl;
        time_line << "Post ID: " << post_id << endl;
        time_line << "User Name: " << Name << endl;
        time_line << "Post details: " << details << endl;
        time_line << "------------------------" << endl;

        // Close the file
        time_line.close();
        cout << "\n\t\tPost shared successfully." << endl;
    }
    else
    {
        cout << "Failed to open 'timelinesharedposts.txt' for writing." << endl;
    }

}

bool Post::containsKeyword(const string& keyword) const
{
    const string& postDetails = details;
    const string& searchWord = keyword;

    int postLen = postDetails.length();
    int wordLen = searchWord.length();

    bool found = true;
    for (int i = 0; i <= postLen - wordLen; i++)
    {

        for (int j = 0; j < wordLen; j++)
        {
            if (postDetails[i + j] != searchWord[j])
            {
                return  false;
                break;
            }
            else
            {
                return true;
            }
        }
    }
}


//Polymorphism 
void Postdetails(string type)
{
    if (type == "Feeling")
    {
        Post* Feeling = new FeelingPost(type);
        Feeling->Postdata();
    }
    else if (type == "Thinking")
    {
        Post* Thinking = new ThinkingPost(type);
        Thinking->Postdata();
    }
    else if (type == "Making")
    {
        Post* Making = new MakingPost(type);
        Making->Postdata();
    }
    else if (type == "Celebrating")
    {
        Post* Celebrating = new CelebratingPost(type);
        Celebrating->Postdata();
    }
}


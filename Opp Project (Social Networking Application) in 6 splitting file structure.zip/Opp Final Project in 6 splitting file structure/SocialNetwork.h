#pragma once
#include<iostream>
#include<string>
#include<fstream>
using namespace std;

class SocialEntity
{
protected:
    string name;
    int id;
public:
    SocialEntity()
    {
        name = "null";
        id = 0;
    }

    static void GetTime();
    SocialEntity(string n, int i);
    string getName() const;
    int getId() const;
};